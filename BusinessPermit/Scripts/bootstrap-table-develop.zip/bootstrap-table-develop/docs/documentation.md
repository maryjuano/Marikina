---
layout: default
title: pages.documentation.title
slug: documentation
lead: pages.documentation.lead
---

{% tf documentation/table-options.md %}

{% tf documentation/column-options.md %}

{% tf documentation/events.md %}

{% tf documentation/methods.md %}

{% tf documentation/localizations.md %}